package com.example.mytranslate;

public class Model {
    public String head;
    public String[] text;
}